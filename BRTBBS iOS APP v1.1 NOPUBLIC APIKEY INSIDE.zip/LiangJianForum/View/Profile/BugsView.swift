//
//  BugsView.swift
//  FlarumiOSApp
//
//  Created by 李正杰 on 2025/2/22.
//

import SwiftUI

struct BugsView: View {
    let listItems = [
        NSLocalizedString("在发送帖子时无法选择标签", comment: ""),
        NSLocalizedString("注册只能用户名和昵称一样", comment: ""),
        NSLocalizedString("无法查看资产记录", comment: ""),
        NSLocalizedString("有些按钮无法点击", comment: "")
    ]

    var body: some View {
        List(0..<listItems.count, id: \.self) { index in
            HStack {
                Text("\(index + 1).")
                    .foregroundColor(.secondary)
                Text(listItems[index])
            }
        }
        .listStyle(.plain)
    }
}
