//
//  APPInfoView.swift
//  FlarumiOSApp
//
//  Created by 李正杰 on 2025/2/20.
//

import UIKit
import SwiftUI
import WebKit

struct APPInfoView: View {
    var body: some View {
        NavigationStack {
            Text("此APP原作者为Romantic D")
            Text("由LeonMMcoset修改")
            Divider()
            Text("使用此APP代表您同意隐私条款")
            List {
                Section {
                    HStack {
                        // 使用 NavigationLink 实现跳转
                        NavigationLink {
                            OriginalGitHubView()
                        } label: {
                            Text("原GitHub页面")
                                .bold()
                        }
                    }
                    HStack {
                        // 使用 NavigationLink 实现跳转
                        NavigationLink {
                            YinSIZhengCeView()
                        } label: {
                            Text("隐私政策")
                                .bold()
                        }
                    }
                }
            }
        }
    }
}

struct OriginalGitHubView : UIViewRepresentable {
    func makeUIView(context: Context) -> WKWebView  {
        return WKWebView()
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {
        let req = URLRequest(url: URL(string: "https://github.com/RomanticD/Flarum-iOS-App-UnofficialDemo")!)
        uiView.load(req)
    }
}

struct YinSIZhengCeView : UIViewRepresentable {
    func makeUIView(context: Context) -> WKWebView  {
        return WKWebView()
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {
        let req = URLRequest(url: URL(string: "http://leonmmcoset.jjmm.ink:1000/web/bbs/public/p/3-yinsizhengce")!)
        uiView.load(req)
    }
}
